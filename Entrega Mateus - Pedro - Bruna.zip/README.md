Integrantes:
Mateus Luiz Salvi - 00229787 - Turma B
Bruna Cagliari - 00290515 - Turma B
Pedro Henrique Augustin - 00246756 - Turma A


Bibliotecas:
Nenhuma biblioteca externa foi usada.


Dados da execução do código:

Tempo de execução BFS: 2.199350595474243 segundos
Nodos expandidos: 272139
Custo até a solução: 23

Tempo de execução DFS: 0.5495567321777344 segundos
Nodos expandidos: 288447
Custo até a solução: 96453

Tempo de execução Hamming: 5.589060306549072 segundos
Nodos expandidos: 46818
Custo até a solução: 23

Tempo de execução Manhattan: 0.10571694374084473 segundos
Nodos expandidos: 5069
Custo até a solução: 23

